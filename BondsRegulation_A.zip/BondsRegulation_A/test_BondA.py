import pytest
from AsrathRahmanBondA import DerivativesIR

#testin gto ensure that a negative RC value returns a zero
def test_RC_negative_is_zero():
    # Assume
    d1 = DerivativesIR("swap_1","2017-01-17T00:00:00Z","ir", "USD", "2019-01-17T00:00:00Z", -1500, 10000, "fixed", "floating",
                       "2017-01-10T00:00:00Z", "vanilla_swap", "2017-01-10T00:00:00Z", "2017-01-16T00:00:00Z")

    # Action
    result = d1.RC(-1500)


    # Assert
    assert result == 0

#testing to see a positive RC value returns a zero
def test_RC_positive_is_not_zero():
    # Assume
    d1 = DerivativesIR("swap_1","2017-01-17T00:00:00Z","ir", "USD", "2019-01-17T00:00:00Z", -1500, 10000, "fixed", "floating",
                       "2017-01-10T00:00:00Z", "vanilla_swap", "2017-01-10T00:00:00Z", "2017-01-16T00:00:00Z")

    # Action
    result = d1.RC(1500)


    # Assert
    assert result != 0

#testing to see a value is returrned when data is input.
def test_adj_notional_is_not_null():
    # Assume
    d1 = DerivativesIR("swap_1", "2017-01-17T00:00:00Z", "ir", "USD", "2019-01-17T00:00:00Z", -1500, 10000, "fixed",
                       "floating", "2017-01-10T00:00:00Z", "vanilla_swap", "2017-01-10T00:00:00Z",
                       "2017-01-16T00:00:00Z")

    # Action
    result = d1.adj_notional(2, 10000)

    # Assert
    assert result != "null"


#testing to see if floating positive effective notional value
def test_floating_returns_positive():
    # Assume
    d1 = DerivativesIR("swap_1", "2017-01-17T00:00:00Z", "ir", "USD", "2019-01-17T00:00:00Z", -1500, 10000, "fixed",
                       "floating", "2017-01-10T00:00:00Z", "vanilla_swap", "2017-01-10T00:00:00Z",
                       "2017-01-16T00:00:00Z")

    # Action
    result = d1.effective_not(10000, "floating")

    # Assert
    assert result > 0

#testing to see if fixed recieve type returns negative
def test_fixed_returns_negative():
    # Assume
    d1 = DerivativesIR("swap_1", "2017-01-17T00:00:00Z", "ir", "USD", "2019-01-17T00:00:00Z", -1500, 10000, "fixed",
                       "floating", "2017-01-10T00:00:00Z", "vanilla_swap", "2017-01-10T00:00:00Z",
                       "2017-01-16T00:00:00Z")

    # Action
    result = d1.effective_not(10000, "fixed")

    # Assert
    assert result < 0

#test to ensure add on method provides value when data input
def test_Addon_is_not_null():
    # Assume
    d1 = DerivativesIR("swap_1", "2017-01-17T00:00:00Z", "ir", "USD", "2019-01-17T00:00:00Z", -1500, 10000, "fixed",
                       "floating", "2017-01-10T00:00:00Z", "vanilla_swap", "2017-01-10T00:00:00Z",
                       "2017-01-16T00:00:00Z")

    # Action
    result = d1.Addon(10000)

    # Assert
    assert result != "null"

#test to ensure EAD method provides value when data input
def test_EAD_is_not_null():
    # Assume
    d1 = DerivativesIR("swap_1", "2017-01-17T00:00:00Z", "ir", "USD", "2019-01-17T00:00:00Z", -1500, 10000, "fixed",
                       "floating", "2017-01-10T00:00:00Z", "vanilla_swap", "2017-01-10T00:00:00Z",
                       "2017-01-16T00:00:00Z")

    # Action
    result = d1.EAD(0, 10000)

    # Assert
    assert result != "null"