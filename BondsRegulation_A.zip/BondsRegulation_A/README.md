Asrath Rahman Derivatives Bond Regulation

Please navigate to BondRegulation_A directory via cd in the terminal.

Then enter into the terminal:
python AsrathRahmanBondA.py

An EAD value should be presented corresponding to the netting set provided in data.json.

To initiate unit tests please enter in the terminal:
pytest -k BondA
