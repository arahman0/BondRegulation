#imports required to manipulate data with python.
import json
import math
from datetime import date, datetime


#generate a class to catalogue methods that can be used to generate EAD.
class DerivativesIR:


#initialise data to be passed through class methods.
    def __init__(self, id, date, asset_class, currency_code, end_date, mtm_dirty, notional_amount, payment_type, receive_type, start_date, type, trade_date, value_date):
        self.id = id
        self.date = date
        self.asset_class = asset_class
        self.currency_code = currency_code
        self.end_date = end_date
        self.mtm_dirty = mtm_dirty
        self.notional_amount = notional_amount
        self.payment_type = payment_type
        self.receive_type = receive_type
        self.start_date = start_date
        self.type = type
        self.trade_date = trade_date
        self.value_date = value_date


    def RC(self, mtm_dirty):
        self.mtm_dirty = mtm_dirty
#making a lists of mtm values to then sum for the RC formula.
        mtm_list = [self.mtm_dirty]
        repCost0 = sum(mtm_list)

#checking to see the summations sign, if negative thus RC = 0.
        if repCost0 > 0:
            return repCost0
        else:
            repCost0 = 0
            return repCost0

        return repCost0


    def adj_notional(self, E, trade_not):
#calculating the adjusted notional value
        self.E = E
        self.trade_not = trade_not
        s = 0

        adjusted_not = trade_not*(((math.exp(-0.05*s)) - (math.exp(-0.05*E)))/0.05)

        return adjusted_not


    def effective_not(self, adjusted_not, recieve_type):
#calculating the effective notional value with appropriate SD according to risk
        self.adjusted_not = adjusted_not
        self.receive_type = recieve_type


        if recieve_type == "floating":
            SD = 1
            effective = (self.adjusted_not) * SD

        else:
            SD = -1
            effective = (self.adjusted_not) * SD

        return effective

    def Addon(self, aggregates):
        self.aggregates = aggregates

        addOn = aggregates*0.005

        return addOn



#assume EAD is unmargined according to task sheet so only one method needed.
    def EAD(self, RepCost1, addOn):
        self.RepCost1 = RepCost1
        self.addOn = addOn

        Ead = 1.4*((self.RepCost1)+(1*self.addOn))
        return Ead



#read through json data and create a list
#empty list set to contain the swap dictionaries
swaps_list = []
#creating a variable to use in RC method after having compaing mtm values of all swaps
mtm_dirty_values = 0
#empty list to store year end values
end_list = []
#empty list to store notional amounts to use as trade notional in formula
trade_not_list = []
#empty list to store receive type
receive_type_list = []
#empty list to store base currency
currency_code_list = []
#empty list to store effective notional amounts
effective_not_list = []
#variable to aggregate effective notional amounts
aggregates = 0

#read json file
try:
    with open('data.json', 'r') as json_file:
        swaps_data = json.loads(json_file.read())
    #iterate over swaps and pass the data through into the Derivatives class
        for swaps in swaps_data['data']:
            swaps_list.append(DerivativesIR(**swaps))
            der0 = DerivativesIR(**swaps)
    #retrieving mtm values from all swaps to summate in the class method variable
            mtm_dirty_values += der0.mtm_dirty
    #retireve the number of years for maturity to use as the end value in the adjusted notional formula
            formatStr = '%Y-%m-%d'
            end = der0.end_date[:10]
            start = der0.start_date[:10]
            endObj = datetime.strptime(end, formatStr)
            startObj = datetime.strptime(start, formatStr)
            endDate = endObj.date()
            startDate = startObj.date()
            delta = (endDate - startDate).days
            maturity = delta//365
            end_list.append(maturity)
    #retrieve the trade notional values
            trade_not_list.append(der0.notional_amount)
    #retrieve the recieve type
            receive_type_list.append(der0.receive_type)
    #retrieve the currency code
            currency_code_list.append(der0.currency_code)


            #notional.append(der.notional_amount)

except:
    print("unable to read file")



#create class object
der1 = DerivativesIR(**swaps)
#retrieve RC value
RepCost1 = der1.RC(mtm_dirty_values)
#use obtained values for the effective notional method and iterate over recieve type
for (i,j,k) in zip(end_list, trade_not_list, receive_type_list):

#append effective notional values to empty list then attatch to currency code to then check if they are in same hedge set
    effective_not_list.append(der1.effective_not(der1.adj_notional(i, j), k))
# summate the effective notional amounts 
n = 0
for (i,j) in zip(currency_code_list, effective_not_list):
    for n in range(1, len(currency_code_list)):
        if i[n] != i[n+1]:
            aggregates += j
        else:
            aggregates += math.sqrt((((j[n]) ** 2)+(j[n+1]) ** 2)+(1.4*(j[n])*(j[n+1])))


#pass the aggregates value into the Addon method to retrieve Addon value
Addon1 = der1.Addon(aggregates)


EAD_value = der1.EAD(mtm_dirty_values, Addon1)
print(f"The EAD value is {math.ceil(EAD_value)}.")













